import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import React from 'react';
import TopHeader from './components/headers/topheader'
import NeuronAbout from './components/neuronAbout/neuronabout'
import NeuronVboutVideo from './components/neuronAboutVideo/neuronaboutvideo'
import NeuronCounterArea from './components/neuroncounterArea/neuronCounterArea'
import CoreServices from './components/coreServices/coreservices'
import { BrowserRouter as Router, Switch, Route }
  from "react-router-dom";
  import NewsLetter from './components/news_letter/news-letter'
  import NeuronPartner from './components/neuron-partner/neuron-partner'
  import WorkProcess from './components/work-process/work-process'
  import RecentBlogs from './components/recent-blog/recent-blog'
  import ContactForm from './components/contact-form/contact-form'
  import Footer from './components/footer/footer'

import "../node_modules/bootstrap/dist/css/bootstrap.css"
import './App.css'
import './spacing.css'
import './responsive.css'
import './fonts/flaticon.css'

import LatestProjects from "./components/latest-projects/latest-projects"

function App() {
  return (
    <>
      <Router>
        <Switch>
          <Route exact path="/">
            <TopHeader />
            <NeuronAbout />
            <NeuronVboutVideo />
            <NeuronCounterArea />
            <CoreServices />
            <LatestProjects />
            <NewsLetter /> 
            <NeuronPartner />
            <WorkProcess />
            <RecentBlogs />
            <ContactForm />
            <Footer />

          </Route>

        </Switch>
      </Router>
    </>
  );
}

export default App;
