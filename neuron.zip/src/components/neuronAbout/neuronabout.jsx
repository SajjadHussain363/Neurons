import React from 'react'
import { Container, Nav, NavDropdown, img, Row, Col } from 'react-bootstrap'
// import Carousel from 'react-bootstrap/Carousel'
// import Slide1 from '../../images/slider.jpg'

const NeuronAbout = () => {
    return <>
        <div className="toplisder-wrapper">
        <div id="neuron-about" className="neuron-about pt-100 pb-100 md-pt-80 md-pb-80">
            <Container className="">                
                <Row className="align-items-center">
                    <Col lg={7} className="pr-60 md-pr-15 md-mb-35">
                        <div className="neuron-about-inner">
                            <Row className="col-20">
                                <Col md={6} className="col-md-6">
                                    <div className="single-about text-center box-shadow mb-40">
                                        <div className="about-icon">
                                            <i className="flaticon-artificial-intelligence"></i>
                                        </div>
                                        <div className="about-title">
                                            <h3 className="title mb-15">Advanced Programing</h3>
                                        </div>
                                        <div className="about-desc">
                                            <p className="desc-txt">Find out what's working and what's not Dig your data to find</p>
                                        </div>
                                    </div>
                                    <div className="single-about text-center box-shadow sm-mb-30">
                                        <div className="about-icon">
                                            <i className="flaticon-ai"></i>
                                        </div>
                                        <div className="about-title">
                                            <h3 className="title mb-15">AI Chippest</h3>
                                        </div>
                                        <div className="about-desc">
                                            <p className="desc-txt">Find out what's working and what's not Dig your data to find</p>
                                        </div>
                                    </div>
                                </Col>

                                <Col md={6} className="mt-100 md-mt-0">
                                    <div className="single-about text-center box-shadow mb-40">
                                        <div className="about-icon">
                                            <i className="flaticon-artificial-intelligence-1"></i>
                                        </div>
                                        <div className="about-title">
                                            <h3 className="title mb-15">Cloud AI intergration</h3>
                                        </div>
                                        <div className="about-desc">
                                            <p className="desc-txt">Find out what's working and what's not Dig your data to find</p>
                                        </div>
                                    </div>
                                    <div className="single-about text-center box-shadow">
                                        <div className="about-icon">
                                            <i className="flaticon-robotic-arm"></i>
                                        </div>
                                        <div className="about-title">
                                            <h3 className="title mb-15">Robotic Arm</h3>
                                        </div>
                                        <div className="about-desc">
                                            <p className="desc-txt">Find out what's working and what's not Dig your data to find</p>
                                        </div>
                                    </div>
                                </Col>


                            </Row>
                        </div>
                    </Col>
                    <Col lg={5} className="pl-0 md-pl-15">
                        <div className="sec-title mb-42">
                            <h2 className="title bg-left">Power Your Creativity With Artificial Intelligence</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis at dictum risus, non suscipit arcu. Quisque aliquam posuere tortor, sit amet convallis nunc scelerisque in.</p>

                            <p className="margin-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Labore eius molesti ae facere, natus reprehenderit eaque eum, autem ipsam. Magni, error. Tem pora odit laborum iure inventore possimus laboriosam qui nam. Fugit!</p>
                        </div>

                        <div className="about-btn">
                            <a className="readon radius" href="#">Learn More</a>
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>

        </div>
    </>
}

export default NeuronAbout;