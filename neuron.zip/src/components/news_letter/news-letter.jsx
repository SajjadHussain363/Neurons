import React from 'react'
import OwlCarousel from 'react-owl-carousel';
import { Container, img, Row, Col } from 'react-bootstrap';
const NewsLetter = () => {
     return (
          <div>
              <div id="neuron-newsletter" className="neuron-newsletter mt-100 md-mt-80 md-pb-80">
                <Container className="">
                    <div className="newsletter-part white-bg box-shadow top-margin pt-130 pb-60 md-pt-50 md-pb-50">
                        <form>
                            <Row className="align-items-center">
                                <Col lg={4} className="">
                                    <div className="newsletter-icon">
                                        <i className="flaticon-mail"></i>
                                    </div>
                                </Col>
                                <Col  lg={8} className="">
                                    <div className="newsletter-text">
                                        <div className="sec-title mb-45">
                                            <h2 className="title margin-0 bg-left">Don’t Miss Our News <br />And Updates!</h2>
                                        </div>
                                        <div className="newsletter-box">
                                            <input type="email" name="email" placeholder="Enter Your Email" required="" />
                                            <button type="submit" className="form-button"><i className="flaticon-send"></i></button>
                                        </div>
                                    </div>
                                </Col>
                            </Row>
                        </form>
                    </div>
                </Container>
            </div>
          </div>

     )
}

export default NewsLetter;
