import React from 'react'
import { Container, Nav, NavDropdown, img, Row, Col } from 'react-bootstrap'
import Countshape from '../../images/countshape.png'

const NeuronCounterArea = () => {
    return <>
        <div>
        <div id="neuron-counter-area" class="neuron-counter-area gradient-bg-section pt-70 pb-70">
            <Container class="container">
                <Row class="neuron-count">
                    <Col lg={3} md={6} class="md-mb-30">
                        <div class="neuron-counter-part text-center">
                            <div class="shape-img">
                                <img src={Countshape} alt="Countshape" />
                            </div>
                            <div class="counter-text text-center">
                                <div class="neuron-counter text-white">6000</div>
                                <h4 class="counter-txt text-white">Complete Project</h4>
                            </div>
                        </div>
                    </Col>

                    <Col lg={3} md={6} class="md-mb-30">
                        <div class="neuron-counter-part text-center">
                            <div class="shape-img">
                                <img src={Countshape} alt="Countshape" />
                            </div>
                            <div class="counter-text text-center">
                                <div class="neuron-counter text-white">400</div>
                                <h4 class="counter-txt text-white">NLP Experts</h4>
                            </div>
                        </div>
                    </Col>

                     <Col lg={3} md={6} class="sm-mb-30">
                        <div class="neuron-counter-part text-center">
                            <div class="shape-img">
                                <img src={Countshape} alt="Countshape" />
                            </div>
                            <div class="counter-text text-center">
                                <div class="neuron-counter text-white">3500</div>
                                <h4 class="counter-txt text-white">Satisfied Clients</h4>
                            </div>
                        </div>
                    </Col>

                    <Col lg={3} md={6}>
                        <div class="neuron-counter-part text-center">
                            <div class="shape-img">
                                <img src={Countshape} alt="Countshape" />
                            </div>
                            <div class="counter-text text-center">
                                <div class="neuron-counter text-white">8000</div>
                                <h4 class="counter-txt text-white">Industries Served</h4>
                            </div>
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
        </div>
    </>
}

export default NeuronCounterArea;