import React from 'react'
import { Container, img, Row, Col } from 'react-bootstrap';
import Logo from '../../images/logo-black.png';
const Footer = () => {
    return (
        <div>
           <footer id="rs-footer" className="rs-footer">
            <div className="footer-top">
                <Container className="">
                    <Row className="">
                        <Col lg={3} md={12} sm={12} className="mb-md-30">
                            <div className="about-widget pr-20">
                                <div className="footer-logo">
                                    <img src={Logo} alt="Footer Logo" />
                                </div>                              
                                <div className="footer-info">
                                    <p className="footer-desc">Lorem ipsum dolor sit amet, conse turini adipiscing elit, sed do eiusmod tempor in cididunt ut labore. </p>
                                </div>                                
                                <ul className="social-links">
                                    <li><a href="#"><i className="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i className="fa fa-instagram"></i></a></li>
                                    <li><a href="#"><i className="fa fa-twitter"></i></a></li>
                                </ul>
                            </div>
                        </Col>

                        <Col  lg={3} md={12} sm={12} className="single-footer-column">
                            <h4 className="footer-title">Work Hours</h4>
                            <p>10.00 AM - 6.00 PM , Monday - Saturday</p>
                            <p>Our Support and Sales team is available 24 * 7 to answer your queries</p>
                        </Col>

                        <Col  lg={3} md={12} sm={12} className="mb-md-30">
                            <div className="footer-menu">
                                <h4 className="footer-title">Navigate</h4>
                                <div className="row">
                                    <div className="col-lg-6 pr-0">
                                        <ul>
                                            <li><a href="about.html">About Us</a></li>
                                            <li><a href="features.html">Features</a></li>
                                            <li><a href="mobile-app.html">Mobile App</a></li>
                                            <li><a href="software-demo.html">Software Demo</a></li>
                                            <li><a href="software-download.html">Software Download</a></li>
                                        </ul>
                                    </div>
                                    <div className="col-lg-6">
                                        <ul>
                                            <li><a href="blog.html">Blog</a></li>
                                            <li><a href="team.html">Team</a></li>
                                            <li><a href="chatbot.html">ChatBot</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </Col>
                        <Col className="col-lg-3 single-footer-column">
                            <div className="footer-menu">
                                <h4 className="footer-title">Privacy &amp; Tos</h4>
                                <ul>
                                    <li><a href="privacy.html">Privacy</a></li>
                                    <li><a href="contact.html">Contact</a></li>
                                    <li><a href="login.html">Login</a></li>
                                    <li><a href="register.html">Register</a></li>
                                </ul>
                            </div>
                        </Col>
                    </Row>
                    <div className="chatbox-part">
                        <div className="chatbox box-shadow white-bg">
                            <div className="chatbox-top gradient-bg">
                                <Row className=" align-items-center">
                                    <Col lg={8} className="">
                                        <div className="chat-img">
                                            <img src="images/team/chat.png" alt="" />
                                            <span className="active-icon"></span>
                                        </div>
                                        <div className="chat-identity pl-10">
                                            <h4 className="chat-title white-color mb-0">ChatBot</h4>
                                            <span className="active-status white-color">Active</span>
                                        </div>
                                    </Col>
                                    <Col  lg={4}>
                                        <div className="close-icon">
                                            <i className="flaticon-error"></i>
                                        </div>
                                    </Col>
                                </Row>
                            </div>
                            <div className="chatbox-text text-center">
                                <p>Hello Friend, I can help you with anything related to chatbots!</p>
                                <p className="mb-0">Let me know if you're planning to create a chatbot for your business!﻿</p>
                            </div>
                            <div className="chatbox-btn">
                                <a className="readon radius" href="#">Let’s Start a Chat</a>
                            </div>
                        </div>
                        <div className="chat-icon text-center">
                            <i className="flaticon-chat"></i>
                        </div>
                    </div>
                </Container>
            </div>
            <div className="footer-bottom">
                <div className="container">                    
                    <div className="copyright text-center">
                        <p>© Copyrights 2020 <a href="#">AuburnForest</a></p>
                    </div>
                </div>
            </div>
        </footer>
        </div>

    )
}

export default Footer;
