import React from 'react'
import OwlCarousel from 'react-owl-carousel';
import { Container, img, Row, Col } from 'react-bootstrap';
import Slidr1 from '../../images/blog/1.jpg'
import Slidr2 from '../../images/blog/2.jpg'
import Slidr3 from '../../images/blog/3.jpg'
const RecentBlogs = () => {
    return (
        <div id="#" className="neuron-blog gray-bg pt-90 pb-175 md-pt-71 md-pb-80">

            <Container>


                <div className="sec-title text-center mb-45">
                    <h2 className="title bg-center">Recent Blog Post</h2>
                </div>


                <OwlCarousel
                    className="owl-theme owl-stage-outer"
                    items={3}
                    autoplay={true}
                    loop={true}
                    margin={30}
                    nav={false}
                    dots={false}
                    responsive={
                        {
                            0: {
                                items: 1
                            },
                            600: {
                                items: 1
                            },
                            1000: {
                                items: 3
                            }
                        }
                    }

                >
                    <div className="recent-blog-item">
                        <img src={Slidr1} alt="Slider 1" />
                        <div className="blog-details box-shadow-2 white-bg">
                            <ul className="blog-meta">
                                <li><i className="fa fa-calendar-check-o" aria-hidden="true"></i>Nov 28, 2019</li>
                                <li><i className="fa fa-user-o" aria-hidden="true"></i>Admin</li>
                                <li><span>10</span>Comments</li>
                            </ul>
                            <div className="blog-desc">
                                <h3 className="blog-title"><a href="#">Man in Red Plaid Shirt Talking on Phone Terrace</a></h3>
                                <p className="blog-txt">The Tutorial covers examples of identification And Rew Garfield and verifies if a picture</p>
                                <div className="blog-btn">
                                    <a className="readon radius capitalize" href="#">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="recent-blog-item">
                        <img src={Slidr2} alt="Slider 2" />
                        <div className="blog-details box-shadow-2 white-bg">
                            <ul className="blog-meta">
                                <li><i className="fa fa-calendar-check-o" aria-hidden="true"></i>Nov 28, 2019</li>
                                <li><i className="fa fa-user-o" aria-hidden="true"></i>Admin</li>
                                <li><span>10</span>Comments</li>
                            </ul>
                            <div className="blog-desc">
                                <h3 className="blog-title"><a href="#">Man in Red Plaid Shirt Talking on Phone Terrace</a></h3>
                                <p className="blog-txt">The Tutorial covers examples of identification And Rew Garfield and verifies if a picture</p>
                                <div className="blog-btn">
                                    <a className="readon radius capitalize" href="#">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="recent-blog-item">
                        <img src={Slidr3} alt="Slider 3" />
                        <div className="blog-details box-shadow-2 white-bg">
                            <ul className="blog-meta">
                                <li><i className="fa fa-calendar-check-o" aria-hidden="true"></i>Nov 28, 2019</li>
                                <li><i className="fa fa-user-o" aria-hidden="true"></i>Admin</li>
                                <li><span>10</span>Comments</li>
                            </ul>
                            <div className="blog-desc">
                                <h3 className="blog-title"><a href="#">Man in Red Plaid Shirt Talking on Phone Terrace</a></h3>
                                <p className="blog-txt">The Tutorial covers examples of identification And Rew Garfield and verifies if a picture</p>
                                <div className="blog-btn">
                                    <a className="readon radius capitalize" href="#">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="recent-blog-item">
                        <img src={Slidr1} alt="Slider 1" />
                        <div className="blog-details box-shadow-2 white-bg">
                            <ul className="blog-meta">
                                <li><i className="fa fa-calendar-check-o" aria-hidden="true"></i>Nov 28, 2019</li>
                                <li><i className="fa fa-user-o" aria-hidden="true"></i>Admin</li>
                                <li><span>10</span>Comments</li>
                            </ul>
                            <div className="blog-desc">
                                <h3 className="blog-title"><a href="#">Man in Red Plaid Shirt Talking on Phone Terrace</a></h3>
                                <p className="blog-txt">The Tutorial covers examples of identification And Rew Garfield and verifies if a picture</p>
                                <div className="blog-btn">
                                    <a className="readon radius capitalize" href="#">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="recent-blog-item">
                        <img src={Slidr2} alt="Slider 2" />
                        <div className="blog-details box-shadow-2 white-bg">
                            <ul className="blog-meta">
                                <li><i className="fa fa-calendar-check-o" aria-hidden="true"></i>Nov 28, 2019</li>
                                <li><i className="fa fa-user-o" aria-hidden="true"></i>Admin</li>
                                <li><span>10</span>Comments</li>
                            </ul>
                            <div className="blog-desc">
                                <h3 className="blog-title"><a href="#">Man in Red Plaid Shirt Talking on Phone Terrace</a></h3>
                                <p className="blog-txt">The Tutorial covers examples of identification And Rew Garfield and verifies if a picture</p>
                                <div className="blog-btn">
                                    <a className="readon radius capitalize" href="#">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="recent-blog-item">
                        <img src={Slidr3} alt="Slider 3" />
                        <div className="blog-details box-shadow-2 white-bg">
                            <ul className="blog-meta">
                                <li><i className="fa fa-calendar-check-o" aria-hidden="true"></i>Nov 28, 2019</li>
                                <li><i className="fa fa-user-o" aria-hidden="true"></i>Admin</li>
                                <li><span>10</span>Comments</li>
                            </ul>
                            <div className="blog-desc">
                                <h3 className="blog-title"><a href="#">Man in Red Plaid Shirt Talking on Phone Terrace</a></h3>
                                <p className="blog-txt">The Tutorial covers examples of identification And Rew Garfield and verifies if a picture</p>
                                <div className="blog-btn">
                                    <a className="readon radius capitalize" href="#">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="recent-blog-item">
                        <img src={Slidr1} alt="Slider 1" />
                        <div className="blog-details box-shadow-2 white-bg">
                            <ul className="blog-meta">
                                <li><i className="fa fa-calendar-check-o" aria-hidden="true"></i>Nov 28, 2019</li>
                                <li><i className="fa fa-user-o" aria-hidden="true"></i>Admin</li>
                                <li><span>10</span>Comments</li>
                            </ul>
                            <div className="blog-desc">
                                <h3 className="blog-title"><a href="#">Man in Red Plaid Shirt Talking on Phone Terrace</a></h3>
                                <p className="blog-txt">The Tutorial covers examples of identification And Rew Garfield and verifies if a picture</p>
                                <div className="blog-btn">
                                    <a className="readon radius capitalize" href="#">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="recent-blog-item">
                        <img src={Slidr2} alt="Slider 2" />
                        <div className="blog-details box-shadow-2 white-bg">
                            <ul className="blog-meta">
                                <li><i className="fa fa-calendar-check-o" aria-hidden="true"></i>Nov 28, 2019</li>
                                <li><i className="fa fa-user-o" aria-hidden="true"></i>Admin</li>
                                <li><span>10</span>Comments</li>
                            </ul>
                            <div className="blog-desc">
                                <h3 className="blog-title"><a href="#">Man in Red Plaid Shirt Talking on Phone Terrace</a></h3>
                                <p className="blog-txt">The Tutorial covers examples of identification And Rew Garfield and verifies if a picture</p>
                                <div className="blog-btn">
                                    <a className="readon radius capitalize" href="#">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="recent-blog-item">
                        <img src={Slidr3} alt="Slider 3" />
                        <div className="blog-details box-shadow-2 white-bg">
                            <ul className="blog-meta">
                                <li><i className="fa fa-calendar-check-o" aria-hidden="true"></i>Nov 28, 2019</li>
                                <li><i className="fa fa-user-o" aria-hidden="true"></i>Admin</li>
                                <li><span>10</span>Comments</li>
                            </ul>
                            <div className="blog-desc">
                                <h3 className="blog-title"><a href="#">Man in Red Plaid Shirt Talking on Phone Terrace</a></h3>
                                <p className="blog-txt">The Tutorial covers examples of identification And Rew Garfield and verifies if a picture</p>
                                <div className="blog-btn">
                                    <a className="readon radius capitalize" href="#">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="recent-blog-item">
                        <img src={Slidr1} alt="Slider 1" />
                        <div className="blog-details box-shadow-2 white-bg">
                            <ul className="blog-meta">
                                <li><i className="fa fa-calendar-check-o" aria-hidden="true"></i>Nov 28, 2019</li>
                                <li><i className="fa fa-user-o" aria-hidden="true"></i>Admin</li>
                                <li><span>10</span>Comments</li>
                            </ul>
                            <div className="blog-desc">
                                <h3 className="blog-title"><a href="#">Man in Red Plaid Shirt Talking on Phone Terrace</a></h3>
                                <p className="blog-txt">The Tutorial covers examples of identification And Rew Garfield and verifies if a picture</p>
                                <div className="blog-btn">
                                    <a className="readon radius capitalize" href="#">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="recent-blog-item">
                        <img src={Slidr2} alt="Slider 2" />
                        <div className="blog-details box-shadow-2 white-bg">
                            <ul className="blog-meta">
                                <li><i className="fa fa-calendar-check-o" aria-hidden="true"></i>Nov 28, 2019</li>
                                <li><i className="fa fa-user-o" aria-hidden="true"></i>Admin</li>
                                <li><span>10</span>Comments</li>
                            </ul>
                            <div className="blog-desc">
                                <h3 className="blog-title"><a href="#">Man in Red Plaid Shirt Talking on Phone Terrace</a></h3>
                                <p className="blog-txt">The Tutorial covers examples of identification And Rew Garfield and verifies if a picture</p>
                                <div className="blog-btn">
                                    <a className="readon radius capitalize" href="#">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="recent-blog-item">
                        <img src={Slidr3} alt="Slider 3" />
                        <div className="blog-details box-shadow-2 white-bg">
                            <ul className="blog-meta">
                                <li><i className="fa fa-calendar-check-o" aria-hidden="true"></i>Nov 28, 2019</li>
                                <li><i className="fa fa-user-o" aria-hidden="true"></i>Admin</li>
                                <li><span>10</span>Comments</li>
                            </ul>
                            <div className="blog-desc">
                                <h3 className="blog-title"><a href="#">Man in Red Plaid Shirt Talking on Phone Terrace</a></h3>
                                <p className="blog-txt">The Tutorial covers examples of identification And Rew Garfield and verifies if a picture</p>
                                <div className="blog-btn">
                                    <a className="readon radius capitalize" href="#">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>

                </OwlCarousel>
            </Container>
        </div>

    )
}

export default RecentBlogs;
