import React from 'react'
import { Container, Nav, NavDropdown, img, Row, Col } from 'react-bootstrap'

const MyCol = props => {
    return (
        <Col lg={4} md={6} className="mb-40">
            <div className="single-about style2 text-center box-shadow">
                <div className="about-icon">
                    <i className={props.icon}></i>
                </div>
                <div className="about-title">
                    <h3 className="title mb-15">{props.title}</h3>
                </div>
                <div className="about-desc">
                    <p className="desc-txt">{props.description}</p>
                </div>
            </div>
        </Col>
    )
}


const items = [
    {
        icon: "flaticon-brain",
        title: "Virtual Personal Assistants",
        description: "Capitalize on low hanging fruit to identify a ball park value added activity to beta test. Override the digital divide with additional"
    },
    {
        icon: "flaticon-automaton",
        title: "Social Media Services",
        description: "Capitalize on low hanging fruit to identify a ball park value added activity to beta test. Override the digital divide with additional"
    },
    {
        icon: "flaticon-artificial-intelligence-2",
        title: "Online Customer Support",
        description: "Capitalize on low hanging fruit to identify a ball park value added activity to beta test. Override the digital divide with additional"
    },
    {
        icon: "flaticon-artificial-intelligence-3",
        title: "Search Engine Result Refining",
        description: "Capitalize on low hanging fruit to identify a ball park value added activity to beta test. Override the digital divide with additional"
    },
    {
        icon: "flaticon-artificial-intelligence-4",
        title: "Online Fraud Detection",
        description: "Capitalize on low hanging fruit to identify a ball park value added activity to beta test. Override the digital divide with additional"
    },
    {
        icon: "flaticon-ai-1",
        title: "Videos Surveillance",
        description: "Capitalize on low hanging fruit to identify a ball park value added activity to beta test. Override the digital divide with additional"
    },
]

const CoreServices = () => {
    return <>
        <div>
            <div className="neuron-about neuron_service gray-bg pt-92 pb-100 md-pt-71 md-pb-80">
                <Container className="">
                    <div className="sec-title text-center mb-50">
                        <h2 className="title bg-center margin-0">Our Core Services</h2>
                    </div>
                    <Row className="col-20">
                        {items.map((item, index) => <MyCol key={"item" + index} title={item.title} description={item.description} icon={item.icon} />)}
                    </Row>
                </Container>
            </div>

        </div>
    </>
}

export default CoreServices;