import React from 'react'
import { Container, Nav, NavDropdown, img, Row, Col } from 'react-bootstrap'
import aboutvideopart from '../../images/aboutvideopart.png'

const NeuronVboutVideo = () => {
    return <>
        <div>
        <div id="neuron-about-video" className="neuron-about-video pb-100 md-pb-70">
            <Container className="">                
                <Row className="align-items-center">
                    <Col lg={6} className="order-last md-mb-40">
                       <div className="about-video-img">
                            <img src={aboutvideopart} alt="about-video-part" />
                       </div>
                    </Col>
                    <Col lg={6} className="">
                        <div className="sec-title mb-36">
                            <h2 className="title bg-left">We Create The Most Realistic Artificial Intelligence</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis at dictum risus, non suscipit arcu. Quisque aliquam posuere tortor, sit amet convallis nunc scelerisque in.</p>

                            <p className="margin-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Labore eius molesti ae facere, natus reprehenderit eaque eum, autem ipsam. Magni, error. Tem pora odit laborum iure inventore possimus laboriosam qui nam. Fugit!</p>
                        </div>

                        <div className="about-btn">
                            <a className="readon radius" href="#">Learn More</a>
                            <div className="media-icon">
                                <a className="popup-videos" href="https://www.youtube.com/watch?v=2PFVhej26BE">
                                    <i className="flaticon-play-button"></i>
                                </a>
                            </div>
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>

        </div>
    </>
}

export default NeuronVboutVideo;