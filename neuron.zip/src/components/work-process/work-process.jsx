import React from 'react'
import { Container, Nav, NavDropdown, img, Row, Col } from 'react-bootstrap'

const WorkProcess = () => {
    return <>
        <div>
        <div id="neuron-work" className="neuron-work pt-90 pb-100 md-pt-71 md-pb-78">
            <Container className=""> 
                <div className="sec-title text-center mb-45">
                    <h2 className="title bg-center">How We Works</h2>
                </div>
                <Row  className="col-20">
                    <Col lg={3}  md={6}  className="md-mb-30">
                        <div className="single-work text-center">
                            <div className="work-icon hover-pulse">
                                <i className="flaticon-code"></i>
                            </div>
                            <div className="work-title">
                                <h3 className="title">Data Generated</h3>
                            </div>
                            <div className="round-shape"></div>
                        </div>                                    
                    </Col>
                    <Col lg={3}  md={6}   className="md-mb-30">
                        <div className="single-work text-center">
                            <div className="work-icon hover-pulse">
                                <i className="flaticon-machine-learning-1"></i>
                            </div>
                            <div className="work-title">
                                <h3 className="title">Data Stored</h3>
                            </div>
                            <div className="round-shape"></div>
                        </div>                                  
                    </Col>
                    <Col lg={3}  md={6}   className="sm-mb-30">
                        <div className="single-work style2 text-center">
                            <div className="work-icon hover-pulse">
                                <i className="flaticon-machine-learning"></i>
                            </div>
                            <div className="work-title">
                                <h3 className="title">Data Processing</h3>
                            </div>                            
                            <div className="round-shape"></div>
                        </div>
                    </Col>
                    <Col lg={3}  md={6}   className="">
                        <div className="single-work text-center extra-none">
                            <div className="work-icon hover-pulse">
                                <i className="flaticon-automaton"></i>
                            </div>
                            <div className="work-title">
                                <h3 className="title">Actionable Insights</h3>
                            </div>
                            <div className="round-shape"></div>
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>

        </div>
    </>
}

export default WorkProcess;