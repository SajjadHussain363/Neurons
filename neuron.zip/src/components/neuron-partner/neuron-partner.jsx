import React from 'react'
import OwlCarousel from 'react-owl-carousel';
import { Container, img} from 'react-bootstrap';
import PartnerOne from '../../images/1.png';
import PartnerTwo from '../../images/2.png';
import PartnerThree from '../../images/3.png';
import PartnerFour from '../../images/4.png';
import PartnerFive from '../../images/5.png';

const MyPartner = props => {
    return (
        <img src={props.img} />
    )
}
const items = [
    {
        image: PartnerOne
    },
    {
        image: PartnerTwo,
    },
    {
        image: PartnerThree,
    },
    {
        image: PartnerFour,
    },
    {
        image: PartnerFive,
    },
    {
        image: PartnerOne,
    },
    {
        image: PartnerTwo,
    },
    {
        image: PartnerThree,
    },
    {
        image: PartnerFour,
    },
    {
        image: PartnerFive,
    }
]


const NeuronPartner = () => {
    return (
        <div>
            <div id="neuron-partner" className="neuron-partner partner-bg pb-100 pt-300 md-pt-80 md-pb-50">
                <Container className="">
                    <ul className="partner-image-part list-inline">
                        {
                            items.map((item, index) => (
                                <li className="partner-item mb-60  list-inline-item">
                                    <MyPartner key={"item" + index} img={item.image} />
                                </li>
                            ))
                        }
                    </ul>

                </Container>
            </div>
        </div>

    )
}

export default NeuronPartner;
