import React from 'react'
import { Container, img, Row, Col } from 'react-bootstrap';

const ContactForm = () => {
    return (
        <div>
            <div id="neuron-contact" className="neuron-contact contact-bg pb-100 md-pb-80">
            <Container className="">
                <Row className="">
                    <Col lg={5} className="pr-30 md-pr-15">
                        <div className="contact-info box-shadow">
                            <div className="contact-info-icon">
                                <i className="flaticon-gps"></i>
                            </div>
                            <div className="sec-title mb-35">
                                <h2 className="title bg-left">Contact With Us</h2>
                            </div>
                            <div className="contact-icon">
                                <div className="icon-part">
                                    <i className="flaticon-place"></i>
                                </div>
                                <div className="icon-text">
                                    <h4 className="icon-title">Visit Us</h4>
                                    <p>530 Old BUffalo Street <br />Northwest #205, New York - 3087</p>
                                </div>
                            </div>
                            <div className="contact-icon">
                                <div className="icon-part">
                                    <i className="flaticon-phone"></i>
                                </div>
                                <div className="icon-text">
                                    <h4 className="icon-title">Call Us</h4>
                                    <a href="tel:+1(123)-456-7890">+1 (123) -456-7890</a>
                                    <a href="tel:+1(123)-456-7890">+1 (123) -456-7890</a>
                                </div>
                            </div>
                            <div className="contact-icon">
                                <div className="icon-part">
                                    <i className="flaticon-mail-1"></i>
                                </div>
                                <div className="icon-text">
                                    <h4 className="icon-title">Email Us</h4>
                                    <a href="mailto:infoname@gmail.com">infoname@gmail.com</a>
                                    <a href="#">www.yourname.com</a>
                                </div>
                            </div>
                        </div>
                    </Col>
                    <Col lg={7}  className="pl-30 md-pl-15">
                        <div className="contact-form pt-100 md-pt-50">
                            <div id="form-messages"></div>
                            <form id="contact-form" method="post" action="#">
                                <div className="row">
                                    <div className="col-md-6 col-sm-12">
                                        <div className="form-field">
                                            <input type="text" placeholder="Name" id="name" name="name" required="" />
                                        </div>                              
                                    </div>
                                    <div className="col-md-6 col-sm-12">
                                        <div className="form-field">
                                            <input type="email" placeholder="E-Mail" id="email" name="email" required="" />
                                        </div>                              
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-6 col-sm-12">
                                        <div className="form-field">
                                            <input type="text" placeholder="Phone Number" id="phone_number" name="phone_number" required="" />
                                        </div>                             
                                    </div>
                                    <div className="col-md-6 col-sm-12">
                                        <div className="form-field">
                                            <input type="text" placeholder="Subject" id="subject" name="subject" required="" />
                                        </div>                              
                                    </div>
                                </div>                        
                                <div className="form-field">
                                    <textarea placeholder="Your Message Here" rows="5" id="message" name="message" required=""></textarea>
                                </div>
                                <div className="form-button">
                                    <button type="submit">Submit Now !</button>
                                </div>
                            </form>
                        </div> 
                    </Col>            
                </Row>
            </Container>
        </div>
        </div>

    )
}

export default ContactForm;
