import React from 'react'
import Navbar from 'react-bootstrap/Navbar'
import logo from '../../images/logo-white.png'
import sl1ly1 from '../../images/sl1ly1.png'
import sl1ly2 from '../../images/sl1ly2.png'

import { Container, Nav, NavDropdown, img, Row, Col } from 'react-bootstrap'
const TopHeader = () => {
    return <>
      <div className="headerSliderTop">
        <header id="rs-header" className="transparent-header">
        <div className="toolbar-area  hidden-sm hidden-xs">
            <div className="container">
                <div className="row">
                    <div className="col-lg-6 col-sm-7 col-xs-12">
                        <div className="toolbar-contact">
                            <ul className="list-inline">
                                <li  className="list-inline-item">
                                    <i className="fa fa-envelope-o"></i>
                                    <a href="mailto:info@yourwebsite.com">info@yourwebsite.com</a>
                                </li>
                                <li className="list-inline-item">
                                    <i className="fa fa-phone"></i>
                                    <a href="tel:+123456789">(+123) 456789</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className="col-lg-6 col-sm-5 col-xs-12">
                        <div className="toolbar-sl-share">
                            <ul className="list-inline text-right">
                                <li className="list-inline-item">
                                    <a href="#">
                                        <i className="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li className="list-inline-item">
                                    <a href="#">
                                        <i className="fa fa-google-plus"></i>
                                    </a>
                                </li>
                                <li className="list-inline-item">
                                    <a href="#">
                                        <i className="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li className="list-inline-item">
                                    <a href="#">
                                        <i className="fa fa-linkedin"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <hr className="hr" />
            </div>
        </div>
        {/* second header */}
        <Container>
        <Navbar collapseOnSelect expand="lg" className="navMain p-0"  variant="dark">
            <Navbar.Brand href="#home">
                <img className="card-img img-fluid" src={logo} alt="Card"/>
                </Navbar.Brand>
            <Navbar.Toggle aria-controls="responsive-navbar-nav" />
            <Navbar.Collapse id="responsive-navbar-nav">
                <Nav className="ml-auto">
                <Nav.Link className="current-menu-item current_page_item menu-item-has-children" href="#Home">Home</Nav.Link>
                <Nav.Link href="#About">About</Nav.Link>
                <Nav.Link href="#Features">Features</Nav.Link>
                <NavDropdown title="Pages" id="collasible-nav-dropdown">
                    <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
                    <NavDropdown.Item href="#action/3.2">Another action</NavDropdown.Item>
                    <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
                    <NavDropdown.Divider />
                    <NavDropdown.Item href="#action/3.4">Separated link</NavDropdown.Item>
                </NavDropdown>
                <Nav.Link href="#Blog">Blog</Nav.Link>
                <Nav.Link eventKey={2} href="#Contact">Contact</Nav.Link>
                <Nav.Link href="#Blog"><i className="fa fa-shopping-bag" aria-hidden="true"></i></Nav.Link>
                <Nav.Link href="#Blog"><i className="fa fa-search"></i></Nav.Link>
                </Nav>
            </Navbar.Collapse>
            </Navbar>
        </Container>
        {/* <img  className="d-block w-100"  src={Slide1} alt="Third slide"  />  */}
        </header>
        <div className="rs-main-slider mt-50">
        <Container>
                <Row md={4}>
                    <Col lg={6} md={8} sm={12} className="p-0">
                        <div className="top-slider-text">
                            <h1 className="white-color mb-0 mt-100 semi-bold text-white" data-animation-in="slideInDown" data-animation-out="animate-out slideOutUp">AI &amp; Machine<br /> Learning Products Creators</h1>
                            <div  className="btm-date">
                                Innovative machine learning products and services<br /> on a trusted platform.
                            </div>
                                <div className="top-btn-slider">
                                    <a href="#" className="btn1" data-animation-in="slideInUp" data-animation-out="animate-out slideOutDown">Learn More</a>
                                    <a href="#" className="btn2" data-animation-in="slideInDown" data-animation-out="animate-out slideOutUp">Join Now</a>
                                </div>
                            </div>
                    </Col>
                    <Col lg={6} md={4}  className="p-0">
                        <div className="slider-image ">
                            <Row className="rs-vertical-bottom">
                                <Col lg={6} md={6} sm={6} xs={6} className="pl-0 pr-10">
                                    <div className="animate1">
                                        <img data-animation-in="bounceInRight" data-animation-out="animate-out fadeOut" src={sl1ly1} alt="layer image" />
                                    </div>
                                </Col>
                                <Col lg={6} md={6} sm={6} xs={6} className="pl-0 pr-0">
                                    <img data-animation-in="bounceInRight" data-animation-out="animate-out fadeOut" src={sl1ly2} alt="layer image" />
                                </Col>
                            </Row>
                        </div>
                    </Col>
                </Row>
            </Container>
            </div>

        </div>
    </>
}

export default TopHeader;