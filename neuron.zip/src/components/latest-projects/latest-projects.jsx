import React from 'react'
import OwlCarousel from 'react-owl-carousel';
import { Container, img, Row, Col } from 'react-bootstrap';
import Slidr1 from '../../images/project/1.jpg'
import Slidr2 from '../../images/project/2.jpg'
import Slidr3 from '../../images/project/3.jpg'
const LatestProjects = () => {
     return (
          <div id="neuron-project-section" className="neuron-project-section pt-92 pb-300 md-pt-71">

               <Container>


                    <div className="sec-title text-center mb-45">
                         <h2 className="title bg-center">Our Latest Project</h2>
                    </div>


                    <OwlCarousel
                         className="owl-theme owl_latest_porject"
                         items={3}
                         autoplay={true}
                         loop={true}
                         margin={30}
                         nav={false}
                         dots={false}
                         responsive={
                              {
                                   0: {
                                        items: 1
                                   },
                                   600: {
                                        items: 1
                                   },
                                   1000: {
                                        items: 3
                                   }
                              }
                         }

                    >
                         <div className="project-item">
                              <img src={Slidr1} alt="Slider 1" />
                              <p>Vocal Avatar API</p>
                         </div>
                         <div className="project-item">
                              <img src={Slidr2} alt="Slider 2" />
                              <p>Vocal Avatar API</p>
                         </div>
                         <div className="project-item">
                              <img src={Slidr3} alt="Slider 3" />
                              <p>Vocal Avatar API</p>
                         </div>
                         <div className="project-item">
                              <img src={Slidr1} alt="Slider 1" />
                              <p>Vocal Avatar API</p>
                         </div>
                         <div className="project-item">
                              <img src={Slidr2} alt="Slider 2" />
                              <p>Vocal Avatar API</p>
                         </div>
                         <div className="project-item">
                              <img src={Slidr3} alt="Slider 3" />
                              <p>Vocal Avatar API</p>
                         </div>
                         <div className="project-item">
                              <img src={Slidr1} alt="Slider 1" />
                              <p>Vocal Avatar API</p>
                         </div>
                         <div className="project-item">
                              <img src={Slidr2} alt="Slider 2" />
                              <p>Vocal Avatar API</p>
                         </div>
                         <div className="project-item">
                              <img src={Slidr3} alt="Slider 3" />
                              <p>Vocal Avatar API</p>
                         </div>
                         <div className="project-item">
                              <img src={Slidr1} alt="Slider 1" />
                              <p>Vocal Avatar API</p>
                         </div>
                         <div className="project-item">
                              <img src={Slidr2} alt="Slider 2" />
                              <p>Vocal Avatar API</p>
                         </div>
                         <div className="project-item">
                              <img src={Slidr3} alt="Slider 3" />
                              <p>Vocal Avatar API</p>
                         </div>

                    </OwlCarousel>
               </Container>
          </div>

     )
}

export default LatestProjects;
